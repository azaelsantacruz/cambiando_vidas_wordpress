jQuery(document).ready(function($){
    sessionStorage.removeItem("wc_cart_hash");
    sessionStorage.removeItem("wc_fragments");
});

