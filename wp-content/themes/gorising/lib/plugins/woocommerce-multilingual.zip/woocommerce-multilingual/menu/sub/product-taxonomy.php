            <?php
                $WPML_Translate_Taxonomy = new WPML_Taxonomy_Translation($current_tab, array('taxonomy_selector'=>false,'status'=> WPML_TT_TAXONOMIES_ALL));
                $WPML_Translate_Taxonomy->render();
            ?>
